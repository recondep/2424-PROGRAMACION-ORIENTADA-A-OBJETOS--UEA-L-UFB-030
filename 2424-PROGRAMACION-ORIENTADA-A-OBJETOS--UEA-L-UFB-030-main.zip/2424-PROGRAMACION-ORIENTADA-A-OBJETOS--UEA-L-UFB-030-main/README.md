# 2424-PROGRAMACION-ORIENTADA-A-OBJETOS--UEA-L-UFB-030

Repositorio de código fuente utilizado en la Asignatura Programación Orientada a Objetos<br>
Institución: Universidad Estatal Amazónica<br>
Carrera: Ingeniería en Tecnologías de la Información y Comunicación<br>
Docente: Ing. Edwin Gustavo Fernández Sánchez, Mgs.